<script setup>
import { ref } from 'vue';
import { Head, useForm, router } from '@inertiajs/vue3';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';

defineProps({
    kelas: Array,
});

const form = useForm({ id: null, nama: '' });
const isEditing = ref(false);

const submit = () => {
    if (isEditing.value) {
        form.put(route('admin.kelas.update', form.id), { onSuccess: resetForm });
    } else {
        form.post(route('admin.kelas.store'), { onSuccess: resetForm });
    }
};

const editItem = (item) => {
    isEditing.value = true;
    form.id = item.id;
    form.nama = item.nama;
};

const resetForm = () => {
    isEditing.value = false;
    form.reset();
    form.clearErrors();
};

const hapus = (item) => {
    if (confirm(`Hapus kelas ${item.nama}?`)) {
        router.delete(route('admin.kelas.destroy', item.id));
    }
};
</script>

<template>
    <Head title="Data Kelas" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold text-gray-800">Data Kelas</h2>
        </template>

        <div class="py-8 max-w-4xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <div class="bg-white shadow rounded-lg p-6">
                <h3 class="text-lg font-medium mb-2">
                    {{ isEditing ? 'Edit' : 'Tambah' }} Kelas
                </h3>
                <p class="text-sm text-gray-500 mb-4">
                    Tulis nama kelas <b>persis sama</b> dengan rombel di aplikasi data induk. Contoh: <code>10 TKJ 1</code>
                </p>
                <form @submit.prevent="submit" class="flex items-start gap-3">
                    <div class="flex-1">
                        <input
                            v-model="form.nama"
                            type="text"
                            placeholder="Contoh: 10 TKJ 1"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                        />
                        <div v-if="form.errors.nama" class="text-sm text-red-600 mt-1">
                            {{ form.errors.nama }}
                        </div>
                    </div>
                    <button type="submit" :disabled="form.processing"
                        class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50">
                        {{ isEditing ? 'Update' : 'Simpan' }}
                    </button>
                    <button v-if="isEditing" type="button" @click="resetForm"
                        class="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300">
                        Batal
                    </button>
                </form>
            </div>

            <div class="bg-white shadow rounded-lg overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama Kelas</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <tr v-for="item in kelas" :key="item.id">
                            <td class="px-6 py-4 font-medium text-gray-900">{{ item.nama }}</td>
                            <td class="px-6 py-4 text-right space-x-3">
                                <button @click="editItem(item)" class="text-blue-600 hover:underline text-sm">Edit</button>
                                <button @click="hapus(item)" class="text-red-600 hover:underline text-sm">Hapus</button>
                            </td>
                        </tr>
                        <tr v-if="kelas.length === 0">
                            <td colspan="2" class="px-6 py-8 text-center text-gray-400">Belum ada data kelas.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
