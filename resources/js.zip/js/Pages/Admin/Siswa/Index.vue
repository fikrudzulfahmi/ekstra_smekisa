<script setup>
import { ref, watch } from 'vue';
import { Head, useForm, router } from '@inertiajs/vue3';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';

const props = defineProps({
    siswa: Array,
    daftarKelas: Array,
    daftarEkstra: Array,
    tahunAktif: Object,
    filters: Object,
});

// Form sinkronisasi
const syncForm = useForm({ kelas_id: '' });

const doSync = () => {
    if (!syncForm.kelas_id) {
        alert('Pilih kelas dulu untuk sinkronisasi.');
        return;
    }
    syncForm.post(route('admin.siswa.sync'), { preserveScroll: true });
};

// Filter kelas (reload halaman dengan query)
const filterKelas = ref(props.filters?.kelas_id ?? '');
watch(filterKelas, (val) => {
    router.get(route('admin.siswa.index'), { kelas_id: val }, {
        preserveState: true,
        preserveScroll: true,
        replace: true,
    });
});

// Ubah ekstra siswa langsung dari dropdown di tabel
const ubahEkstra = (siswa, event) => {
    router.patch(route('admin.siswa.ekstra', siswa.id), {
        ekstra_id: event.target.value || null,
    }, { preserveScroll: true });
};

const hapus = (item) => {
    if (confirm(`Hapus siswa ${item.nama}?`)) {
        router.delete(route('admin.siswa.destroy', item.id), { preserveScroll: true });
    }
};
</script>

<template>
    <Head title="Data Siswa" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold text-gray-800">Data Siswa</h2>
        </template>

        <div class="py-8 max-w-6xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <!-- Info Tahun Aktif -->
            <div v-if="!tahunAktif" class="bg-red-50 border border-red-200 text-red-700 rounded-lg p-4 text-sm">
                Belum ada tahun pelajaran aktif. Set dulu di menu Tahun Pelajaran.
            </div>
            <div v-else class="bg-blue-50 border border-blue-200 text-blue-700 rounded-lg p-3 text-sm">
                Tahun Pelajaran Aktif: <b>{{ tahunAktif.nama }}</b> — semua data siswa di bawah ini terikat tahun ini.
            </div>

            <!-- Panel Sinkronisasi -->
            <div class="bg-white shadow rounded-lg p-6">
                <h3 class="text-lg font-medium mb-2">Sinkronisasi Siswa dari Data Induk</h3>
                <p class="text-sm text-gray-500 mb-4">
                    Pilih kelas, lalu tarik data siswa dari aplikasi data induk melalui API.
                </p>
                <div class="flex items-end gap-3">
                    <div class="flex-1 max-w-xs">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Kelas</label>
                        <select v-model="syncForm.kelas_id"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
                            <option value="">-- Pilih Kelas --</option>
                            <option v-for="k in daftarKelas" :key="k.id" :value="k.id">{{ k.nama }}</option>
                        </select>
                    </div>
                    <button @click="doSync" :disabled="syncForm.processing"
                        class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50">
                        {{ syncForm.processing ? 'Menyinkron...' : 'Sinkronisasi' }}
                    </button>
                </div>
            </div>

            <!-- Filter & Tabel -->
            <div class="bg-white shadow rounded-lg overflow-hidden">
                <div class="p-4 border-b flex items-center gap-3">
                    <label class="text-sm font-medium text-gray-700">Filter Kelas:</label>
                    <select v-model="filterKelas"
                        class="border-gray-300 rounded-md shadow-sm text-sm focus:ring-indigo-500 focus:border-indigo-500">
                        <option value="">Semua Kelas</option>
                        <option v-for="k in daftarKelas" :key="k.id" :value="k.id">{{ k.nama }}</option>
                    </select>
                    <span class="text-sm text-gray-400 ml-auto">Total: {{ siswa.length }} siswa</span>
                </div>

                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">NIS</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">JK</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kelas</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ekstra</th>
                            <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <tr v-for="item in siswa" :key="item.id">
                            <td class="px-4 py-3 text-sm text-gray-500">{{ item.nis || '-' }}</td>
                            <td class="px-4 py-3 text-sm font-medium text-gray-900">{{ item.nama }}</td>
                            <td class="px-4 py-3 text-sm">{{ item.jk || '-' }}</td>
                            <td class="px-4 py-3 text-sm">{{ item.kelas?.nama }}</td>
                            <td class="px-4 py-3 text-sm">
                                <select :value="item.ekstra_id ?? ''" @change="ubahEkstra(item, $event)"
                                    class="border-gray-300 rounded-md text-sm py-1 focus:ring-indigo-500 focus:border-indigo-500">
                                    <option value="">- Belum ikut -</option>
                                    <option v-for="e in daftarEkstra" :key="e.id" :value="e.id">{{ e.nama }}</option>
                                </select>
                            </td>
                            <td class="px-4 py-3 text-right">
                                <button @click="hapus(item)" class="text-red-600 hover:underline text-sm">Hapus</button>
                            </td>
                        </tr>
                        <tr v-if="siswa.length === 0">
                            <td colspan="6" class="px-4 py-8 text-center text-gray-400">
                                Belum ada data siswa. Lakukan sinkronisasi di atas.
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
