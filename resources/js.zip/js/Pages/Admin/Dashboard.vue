<script setup>
import { Head } from '@inertiajs/vue3';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
</script>

<template>
    <Head title="Dashboard Admin" />
    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold text-gray-800">Dashboard Admin</h2>
        </template>
        <div class="py-8 max-w-6xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow rounded-lg p-6">
                <p class="text-gray-600">Selamat datang di panel admin aplikasi presensi ekstrakurikuler.</p>
                <p class="text-sm text-gray-400 mt-2">Gunakan menu di samping untuk mengelola data.</p>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
