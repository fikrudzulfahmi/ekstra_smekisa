<script setup>
import { ref } from 'vue';
import { Head, useForm, router } from '@inertiajs/vue3';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';

const props = defineProps({
    pelatih: Array,
    daftarEkstra: Array,
});

const form = useForm({
    id: null,
    nama: '',
    email: '',
    password: '',
    no_hp: '',
    ekstra_ids: [],
});

const isEditing = ref(false);

const submit = () => {
    if (isEditing.value) {
        form.put(route('admin.pelatih.update', form.id), { onSuccess: resetForm });
    } else {
        form.post(route('admin.pelatih.store'), { onSuccess: resetForm });
    }
};

const editItem = (item) => {
    isEditing.value = true;
    form.id = item.id;
    form.nama = item.nama;
    form.email = item.user.email;
    form.password = '';
    form.no_hp = item.no_hp ?? '';
    form.ekstra_ids = item.ekstra.map((e) => e.id); // ambil id ekstra yg sudah ter-assign
};

const resetForm = () => {
    isEditing.value = false;
    form.reset();
    form.clearErrors();
};

const hapus = (item) => {
    if (confirm(`Hapus pelatih ${item.nama}? Akun login-nya juga akan dihapus.`)) {
        router.delete(route('admin.pelatih.destroy', item.id));
    }
};
</script>

<template>
    <Head title="Data Pelatih" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold text-gray-800">Data Pelatih</h2>
        </template>

        <div class="py-8 max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <!-- Form -->
            <div class="bg-white shadow rounded-lg p-6">
                <h3 class="text-lg font-medium mb-4">
                    {{ isEditing ? 'Edit' : 'Tambah' }} Pelatih
                </h3>
                <form @submit.prevent="submit" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Nama</label>
                        <input v-model="form.nama" type="text"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500" />
                        <div v-if="form.errors.nama" class="text-sm text-red-600 mt-1">{{ form.errors.nama }}</div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">No. HP</label>
                        <input v-model="form.no_hp" type="text"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500" />
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Email (untuk login)</label>
                        <input v-model="form.email" type="email"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500" />
                        <div v-if="form.errors.email" class="text-sm text-red-600 mt-1">{{ form.errors.email }}</div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">
                            Password
                            <span v-if="isEditing" class="text-xs text-gray-400">(kosongkan jika tidak diubah)</span>
                        </label>
                        <input v-model="form.password" type="password"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500" />
                        <div v-if="form.errors.password" class="text-sm text-red-600 mt-1">{{ form.errors.password }}</div>
                    </div>

                    <!-- Pilih Ekstra (many-to-many) -->
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Ekstra yang Dilatih</label>
                        <div class="flex flex-wrap gap-3">
                            <label v-for="e in daftarEkstra" :key="e.id"
                                class="inline-flex items-center gap-2 border rounded-md px-3 py-2 cursor-pointer hover:bg-gray-50">
                                <input type="checkbox" :value="e.id" v-model="form.ekstra_ids"
                                    class="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500" />
                                <span class="text-sm">{{ e.nama }}</span>
                            </label>
                            <p v-if="daftarEkstra.length === 0" class="text-sm text-gray-400">
                                Belum ada data ekstra. Tambahkan dulu di menu Ekstra.
                            </p>
                        </div>
                    </div>

                    <div class="md:col-span-2 flex gap-3">
                        <button type="submit" :disabled="form.processing"
                            class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50">
                            {{ isEditing ? 'Update' : 'Simpan' }}
                        </button>
                        <button v-if="isEditing" type="button" @click="resetForm"
                            class="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300">
                            Batal
                        </button>
                    </div>
                </form>
            </div>

            <!-- Tabel -->
            <div class="bg-white shadow rounded-lg overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ekstra</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <tr v-for="item in pelatih" :key="item.id">
                            <td class="px-6 py-4 font-medium text-gray-900">{{ item.nama }}</td>
                            <td class="px-6 py-4 text-sm text-gray-500">{{ item.user.email }}</td>
                            <td class="px-6 py-4 text-sm">
                                <span v-for="e in item.ekstra" :key="e.id"
                                    class="inline-block bg-indigo-100 text-indigo-700 rounded px-2 py-0.5 text-xs mr-1 mb-1">
                                    {{ e.nama }}
                                </span>
                                <span v-if="item.ekstra.length === 0" class="text-gray-400 text-xs">-</span>
                            </td>
                            <td class="px-6 py-4 text-right space-x-3">
                                <button @click="editItem(item)" class="text-blue-600 hover:underline text-sm">Edit</button>
                                <button @click="hapus(item)" class="text-red-600 hover:underline text-sm">Hapus</button>
                            </td>
                        </tr>
                        <tr v-if="pelatih.length === 0">
                            <td colspan="4" class="px-6 py-8 text-center text-gray-400">Belum ada data pelatih.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
