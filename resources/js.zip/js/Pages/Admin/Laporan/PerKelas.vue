<script setup>
import { reactive } from 'vue';
import { Head, router, Link } from '@inertiajs/vue3';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';

const props = defineProps({
    laporan: Array,
    daftarKelas: Array,
    tahunAktif: Object,
    namaKelas: String,
    filters: Object,
});

const filter = reactive({
    kelas_id: props.filters?.kelas_id ?? '',
    tgl_mulai: props.filters?.tgl_mulai ?? '',
    tgl_selesai: props.filters?.tgl_selesai ?? '',
});

const terapkan = () => {
    if (!filter.kelas_id) {
        alert('Pilih kelas dulu.');
        return;
    }
    router.get(route('admin.laporan.per-kelas'), { ...filter }, {
        preserveState: true,
        preserveScroll: true,
    });
};

const cetak = () => window.print();

const persentase = (item) => {
    if (item.total_count === 0) return 0;
    return Math.round((item.hadir_count / item.total_count) * 100);
};

const formatTgl = (t) =>
    new Date(t).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
</script>

<template>
    <Head title="Laporan Kehadiran per Kelas" />

    <AuthenticatedLayout>
        <template #header>
            <div class="flex items-center justify-between">
                <h2 class="text-xl font-semibold text-gray-800">Laporan Kehadiran per Kelas</h2>
                <Link :href="route('admin.laporan.index')" class="text-sm text-indigo-600 hover:underline print:hidden">
                    Laporan per Kegiatan &rarr;
                </Link>
            </div>
        </template>

        <div class="py-8 max-w-6xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <!-- Panel Filter -->
            <div class="bg-white shadow rounded-lg p-6 print:hidden">
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Kelas</label>
                        <select v-model="filter.kelas_id"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
                            <option value="">-- Pilih Kelas --</option>
                            <option v-for="k in daftarKelas" :key="k.id" :value="k.id">{{ k.nama }}</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Dari Tanggal</label>
                        <input v-model="filter.tgl_mulai" type="date"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500" />
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Sampai Tanggal</label>
                        <input v-model="filter.tgl_selesai" type="date"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500" />
                    </div>
                    <div class="flex gap-2">
                        <button @click="terapkan"
                            class="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                            Tampilkan
                        </button>
                    </div>
                </div>
            </div>

            <!-- Header Laporan (tampil saat ada data) -->
            <div v-if="namaKelas" class="bg-white shadow rounded-lg p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold">Rekap Kehadiran — Kelas {{ namaKelas }}</h3>
                        <p class="text-sm text-gray-500">
                            Periode: {{ formatTgl(filters.tgl_mulai) }} s/d {{ formatTgl(filters.tgl_selesai) }}
                            &bull; Tahun Pelajaran {{ tahunAktif?.nama }}
                        </p>
                    </div>
                    <button @click="cetak"
                        class="px-3 py-1.5 bg-gray-100 text-gray-700 rounded-md text-sm hover:bg-gray-200 print:hidden">
                        🖨️ Cetak
                    </button>
                </div>
            </div>

            <!-- Tabel Rekap per Siswa -->
            <div v-if="namaKelas" class="bg-white shadow rounded-lg overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">No</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama Siswa</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ekstra</th>
                            <th class="px-4 py-3 text-center text-xs font-medium text-green-600 uppercase">Hadir</th>
                            <th class="px-4 py-3 text-center text-xs font-medium text-yellow-600 uppercase">Izin</th>
                            <th class="px-4 py-3 text-center text-xs font-medium text-orange-600 uppercase">Sakit</th>
                            <th class="px-4 py-3 text-center text-xs font-medium text-red-600 uppercase">Alpha</th>
                            <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Total</th>
                            <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">%</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <tr v-for="(s, i) in laporan" :key="s.id">
                            <td class="px-4 py-3 text-sm text-gray-500">{{ i + 1 }}</td>
                            <td class="px-4 py-3 text-sm font-medium text-gray-900">{{ s.nama }}</td>
                            <td class="px-4 py-3 text-sm text-gray-500">{{ s.ekstra?.nama ?? '-' }}</td>
                            <td class="px-4 py-3 text-sm text-center font-semibold text-green-600">{{ s.hadir_count }}</td>
                            <td class="px-4 py-3 text-sm text-center text-yellow-600">{{ s.izin_count }}</td>
                            <td class="px-4 py-3 text-sm text-center text-orange-600">{{ s.sakit_count }}</td>
                            <td class="px-4 py-3 text-sm text-center text-red-600">{{ s.alpha_count }}</td>
                            <td class="px-4 py-3 text-sm text-center text-gray-700">{{ s.total_count }}</td>
                            <td class="px-4 py-3 text-sm text-center">
                                <span :class="[
                                    'px-2 py-0.5 rounded text-xs font-semibold',
                                    persentase(s) >= 75 ? 'bg-green-100 text-green-700' :
                                    persentase(s) >= 50 ? 'bg-yellow-100 text-yellow-700' :
                                    'bg-red-100 text-red-700'
                                ]">{{ persentase(s) }}%</span>
                            </td>
                        </tr>
                        <tr v-if="laporan.length === 0">
                            <td colspan="9" class="px-4 py-8 text-center text-gray-400">
                                Tidak ada siswa di kelas ini pada periode tersebut.
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Placeholder saat belum pilih kelas -->
            <div v-else class="bg-white shadow rounded-lg p-8 text-center text-gray-400 print:hidden">
                Pilih kelas dan rentang tanggal, lalu klik "Tampilkan".
            </div>
        </div>
    </AuthenticatedLayout>
</template>
