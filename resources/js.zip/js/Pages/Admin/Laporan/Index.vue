<script setup>
import { ref, watch } from 'vue';
import { Head, router } from '@inertiajs/vue3';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';

const props = defineProps({
    kegiatan: Array,
    daftarEkstra: Array,
    tahunAktif: Object,
    filters: Object,
    ringkasan: Object,
});

const filterEkstra = ref(props.filters?.ekstra_id ?? '');
watch(filterEkstra, (val) => {
    router.get(route('admin.laporan.index'), { ekstra_id: val }, {
        preserveState: true,
        preserveScroll: true,
        replace: true,
    });
});

const formatTanggal = (tgl) =>
    new Date(tgl).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });

const persentaseHadir = (item) => {
    if (item.total_count === 0) return 0;
    return Math.round((item.hadir_count / item.total_count) * 100);
};

// ✅ Perbaikan tombol cetak
const cetak = () => window.print();

// ✅ Modal foto
const fotoModal = ref(null);
const bukaFoto = (path) => { fotoModal.value = `/storage/${path}`; };
const tutupFoto = () => { fotoModal.value = null; };
</script>


<template>
    <Head title="Laporan Rekap Kegiatan" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold text-gray-800">Laporan Rekap Kegiatan</h2>
        </template>

        <div class="py-8 max-w-6xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <!-- Info Tahun Aktif -->
            <div class="bg-blue-50 border border-blue-200 text-blue-700 rounded-lg p-3 text-sm">
                Tahun Pelajaran Aktif: <b>{{ tahunAktif?.nama ?? '-' }}</b>
            </div>

            <!-- Kartu Ringkasan -->
            <div class="grid grid-cols-2 md:grid-cols-5 gap-3">
                <div class="bg-white shadow rounded-lg p-4 text-center">
                    <div class="text-2xl font-bold text-gray-800">{{ ringkasan.total_kegiatan }}</div>
                    <div class="text-xs text-gray-500">Total Kegiatan</div>
                </div>
                <div class="bg-green-50 rounded-lg p-4 text-center">
                    <div class="text-2xl font-bold text-green-700">{{ ringkasan.total_hadir }}</div>
                    <div class="text-xs text-green-600">Total Hadir</div>
                </div>
                <div class="bg-yellow-50 rounded-lg p-4 text-center">
                    <div class="text-2xl font-bold text-yellow-700">{{ ringkasan.total_izin }}</div>
                    <div class="text-xs text-yellow-600">Total Izin</div>
                </div>
                <div class="bg-orange-50 rounded-lg p-4 text-center">
                    <div class="text-2xl font-bold text-orange-700">{{ ringkasan.total_sakit }}</div>
                    <div class="text-xs text-orange-600">Total Sakit</div>
                </div>
                <div class="bg-red-50 rounded-lg p-4 text-center">
                    <div class="text-2xl font-bold text-red-700">{{ ringkasan.total_alpha }}</div>
                    <div class="text-xs text-red-600">Total Alpha</div>
                </div>
            </div>

            <!-- Filter & Tabel -->
            <div class="bg-white shadow rounded-lg overflow-hidden">
                <div class="p-4 border-b flex items-center gap-3">
                    <label class="text-sm font-medium text-gray-700">Filter Ekstra:</label>
                    <select v-model="filterEkstra"
                        class="border-gray-300 rounded-md shadow-sm text-sm focus:ring-indigo-500 focus:border-indigo-500">
                        <option value="">Semua Ekstra</option>
                        <option v-for="e in daftarEkstra" :key="e.id" :value="e.id">{{ e.nama }}</option>
                    </select>
                    <button @click="cetak"
    class="ml-auto px-3 py-1.5 bg-gray-100 text-gray-700 rounded-md text-sm hover:bg-gray-200 print:hidden">
    🖨️ Cetak
</button>

                </div>

               <table class="min-w-full divide-y divide-gray-200">
    <thead class="bg-gray-50">
        <tr>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tanggal</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ekstra</th>
            <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Foto</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Materi</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Pelatih</th>
            <th class="px-4 py-3 text-center text-xs font-medium text-green-600 uppercase">H</th>
            <th class="px-4 py-3 text-center text-xs font-medium text-yellow-600 uppercase">I</th>
            <th class="px-4 py-3 text-center text-xs font-medium text-orange-600 uppercase">S</th>
            <th class="px-4 py-3 text-center text-xs font-medium text-red-600 uppercase">A</th>
            <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">% Hadir</th>
        </tr>
    </thead>
    <tbody class="divide-y divide-gray-200">
        <tr v-for="item in kegiatan" :key="item.id">
            <td class="px-4 py-3 text-sm text-gray-600">{{ formatTanggal(item.tanggal) }}</td>
            <td class="px-4 py-3 text-sm">
                <span class="bg-indigo-100 text-indigo-700 rounded px-2 py-0.5 text-xs">{{ item.ekstra?.nama }}</span>
            </td>
            <!-- ✅ Kolom Foto -->
            <td class="px-4 py-3 text-center">
                <img v-if="item.foto" :src="`/storage/${item.foto}`" alt="Foto"
                    class="h-10 w-10 rounded object-cover inline-block cursor-pointer hover:opacity-80 transition"
                    @click="bukaFoto(item.foto)" />
                <span v-else class="text-gray-300 text-xs">-</span>
            </td>
            <td class="px-4 py-3 text-sm font-medium text-gray-900">{{ item.materi }}</td>
            <td class="px-4 py-3 text-sm text-gray-500">{{ item.pelatih?.nama }}</td>
            <td class="px-4 py-3 text-sm text-center font-semibold text-green-600">{{ item.hadir_count }}</td>
            <td class="px-4 py-3 text-sm text-center text-yellow-600">{{ item.izin_count }}</td>
            <td class="px-4 py-3 text-sm text-center text-orange-600">{{ item.sakit_count }}</td>
            <td class="px-4 py-3 text-sm text-center text-red-600">{{ item.alpha_count }}</td>
            <td class="px-4 py-3 text-sm text-center">
                <span :class="[
                    'px-2 py-0.5 rounded text-xs font-semibold',
                    persentaseHadir(item) >= 75 ? 'bg-green-100 text-green-700' :
                    persentaseHadir(item) >= 50 ? 'bg-yellow-100 text-yellow-700' :
                    'bg-red-100 text-red-700'
                ]">
                    {{ persentaseHadir(item) }}%
                </span>
            </td>
        </tr>
        <tr v-if="kegiatan.length === 0">
            <td colspan="10" class="px-4 py-8 text-center text-gray-400">
                Belum ada data kegiatan untuk ditampilkan.
            </td>
        </tr>
    </tbody>
</table>

            </div>
        </div>
    </AuthenticatedLayout>
    <!-- Modal Preview Foto -->
<div v-if="fotoModal" @click="tutupFoto"
    class="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 cursor-pointer print:hidden">
    <img :src="fotoModal" alt="Foto Kegiatan" class="max-h-[90vh] max-w-[90vw] rounded-lg shadow-2xl" />
</div>

</template>
