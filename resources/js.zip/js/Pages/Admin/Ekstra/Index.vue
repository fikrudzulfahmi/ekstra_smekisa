<script setup>
import { ref } from 'vue';
import { Head, useForm, router } from '@inertiajs/vue3';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';

defineProps({
    ekstra: Array,
});

const form = useForm({ id: null, nama: '', deskripsi: '' });
const isEditing = ref(false);

const submit = () => {
    if (isEditing.value) {
        form.put(route('admin.ekstra.update', form.id), { onSuccess: resetForm });
    } else {
        form.post(route('admin.ekstra.store'), { onSuccess: resetForm });
    }
};

const editItem = (item) => {
    isEditing.value = true;
    form.id = item.id;
    form.nama = item.nama;
    form.deskripsi = item.deskripsi ?? '';
};

const resetForm = () => {
    isEditing.value = false;
    form.reset();
    form.clearErrors();
};

const hapus = (item) => {
    if (confirm(`Hapus ekstrakurikuler ${item.nama}?`)) {
        router.delete(route('admin.ekstra.destroy', item.id));
    }
};
</script>

<template>
    <Head title="Data Ekstrakurikuler" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold text-gray-800">Data Ekstrakurikuler</h2>
        </template>

        <div class="py-8 max-w-4xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <div class="bg-white shadow rounded-lg p-6">
                <h3 class="text-lg font-medium mb-4">
                    {{ isEditing ? 'Edit' : 'Tambah' }} Ekstrakurikuler
                </h3>
                <form @submit.prevent="submit" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Nama Ekstra</label>
                        <input
                            v-model="form.nama"
                            type="text"
                            placeholder="Contoh: Pramuka"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                        />
                        <div v-if="form.errors.nama" class="text-sm text-red-600 mt-1">{{ form.errors.nama }}</div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Deskripsi (opsional)</label>
                        <textarea
                            v-model="form.deskripsi"
                            rows="2"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                        ></textarea>
                    </div>
                    <div class="flex gap-3">
                        <button type="submit" :disabled="form.processing"
                            class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50">
                            {{ isEditing ? 'Update' : 'Simpan' }}
                        </button>
                        <button v-if="isEditing" type="button" @click="resetForm"
                            class="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300">
                            Batal
                        </button>
                    </div>
                </form>
            </div>

            <div class="bg-white shadow rounded-lg overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Deskripsi</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <tr v-for="item in ekstra" :key="item.id">
                            <td class="px-6 py-4 font-medium text-gray-900">{{ item.nama }}</td>
                            <td class="px-6 py-4 text-gray-500 text-sm">{{ item.deskripsi || '-' }}</td>
                            <td class="px-6 py-4 text-right space-x-3">
                                <button @click="editItem(item)" class="text-blue-600 hover:underline text-sm">Edit</button>
                                <button @click="hapus(item)" class="text-red-600 hover:underline text-sm">Hapus</button>
                            </td>
                        </tr>
                        <tr v-if="ekstra.length === 0">
                            <td colspan="3" class="px-6 py-8 text-center text-gray-400">Belum ada data ekstrakurikuler.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
