<script setup>
import { reactive, computed } from 'vue';
import { Head, useForm } from '@inertiajs/vue3';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';

const props = defineProps({
    kegiatan: Object,
    presensiGrup: Object, // { "10 TKJ 1": [ {id, status, siswa:{nama}} ] }
    rekap: Object,
});

const form = useForm({
    tanggal: props.kegiatan.tanggal?.substring(0, 10),
    materi: props.kegiatan.materi,
    deskripsi: props.kegiatan.deskripsi ?? '',
    foto: null,   // ← tambah ini
    presensi: [],
});


// Peta status per id presensi
const statusMap = reactive({});
Object.values(props.presensiGrup).flat().forEach((p) => {
    statusMap[p.id] = p.status;
});

const STATUS = ['hadir', 'izin', 'sakit', 'alpha'];

const submit = () => {
    form.presensi = Object.entries(statusMap).map(([id, status]) => ({
        id: Number(id),   // ← id presensi (jujur namanya)
        status,
    }));
    form.transform((data) => ({ ...data, _method: 'put' }))
        .post(route('pelatih.kegiatan.update', props.kegiatan.id));
};

const previewUrl = computed(() =>
    form.foto ? URL.createObjectURL(form.foto) : null
);

const warnaStatus = (status) => ({
    hadir: 'bg-green-100 text-green-700',
    izin:  'bg-yellow-100 text-yellow-700',
    sakit: 'bg-orange-100 text-orange-700',
    alpha: 'bg-red-100 text-red-700',
}[status]);
</script>

<template>
    <Head title="Edit Kegiatan" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold text-gray-800">Edit Kegiatan — {{ kegiatan.ekstra.nama }}</h2>
        </template>

        <div class="py-8 max-w-4xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <!-- Rekap Kehadiran -->
            <div class="bg-white shadow rounded-lg p-5">
                <h3 class="text-sm font-medium text-gray-500 mb-3">Rekap Kehadiran Kegiatan Ini</h3>
                <div class="grid grid-cols-5 gap-3 text-center">
                    <div class="bg-green-50 rounded-lg p-3">
                        <div class="text-2xl font-bold text-green-600">{{ rekap.hadir }}</div>
                        <div class="text-xs text-gray-500">Hadir</div>
                    </div>
                    <div class="bg-yellow-50 rounded-lg p-3">
                        <div class="text-2xl font-bold text-yellow-600">{{ rekap.izin }}</div>
                        <div class="text-xs text-gray-500">Izin</div>
                    </div>
                    <div class="bg-orange-50 rounded-lg p-3">
                        <div class="text-2xl font-bold text-orange-600">{{ rekap.sakit }}</div>
                        <div class="text-xs text-gray-500">Sakit</div>
                    </div>
                    <div class="bg-red-50 rounded-lg p-3">
                        <div class="text-2xl font-bold text-red-600">{{ rekap.alpha }}</div>
                        <div class="text-xs text-gray-500">Alpha</div>
                    </div>
                    <div class="bg-gray-50 rounded-lg p-3">
                        <div class="text-2xl font-bold text-gray-700">{{ rekap.total }}</div>
                        <div class="text-xs text-gray-500">Total</div>
                    </div>
                </div>
            </div>

            <form @submit.prevent="submit" class="space-y-6">
                <!-- Detail -->
                <div class="bg-white shadow rounded-lg p-6 space-y-4">
                    <h3 class="text-lg font-medium">Detail Kegiatan</h3>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Tanggal</label>
                        <input v-model="form.tanggal" type="date"
                            class="w-full max-w-xs border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500" />
                        <div v-if="form.errors.tanggal" class="text-sm text-red-600 mt-1">{{ form.errors.tanggal }}</div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Materi</label>
                        <input v-model="form.materi" type="text"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500" />
                        <div v-if="form.errors.materi" class="text-sm text-red-600 mt-1">{{ form.errors.materi }}</div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Deskripsi</label>
                        <textarea v-model="form.deskripsi" rows="3"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"></textarea>
                    </div>
                    <div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Foto Kegiatan</label>

    <!-- Foto saat ini (jika ada & belum pilih foto baru) -->
    <div v-if="kegiatan.foto && !form.foto" class="mb-2">
        <p class="text-xs text-gray-400 mb-1">Foto saat ini:</p>
        <img :src="`/storage/${kegiatan.foto}`" alt="Foto saat ini"
            class="h-32 rounded-md border object-cover" />
    </div>

    <input type="file" accept="image/*" capture="environment"
        @change="form.foto = $event.target.files[0]"
        class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100" />
    <p class="text-xs text-gray-400 mt-1">Kosongkan jika tidak ingin mengganti foto. Maks 5MB.</p>
    <div v-if="form.errors.foto" class="text-sm text-red-600 mt-1">{{ form.errors.foto }}</div>

    <!-- Preview foto baru -->
    <div v-if="form.foto" class="mt-2">
        <p class="text-xs text-gray-400 mb-1">Foto baru:</p>
        <img :src="previewUrl" alt="Preview" class="h-32 rounded-md border object-cover" />
    </div>
</div>

                </div>

                <!-- Presensi per kelas -->
                <div class="bg-white shadow rounded-lg p-6 space-y-6">
                    <h3 class="text-lg font-medium">Presensi Siswa</h3>
                    <div v-for="(list, namaKelas) in presensiGrup" :key="namaKelas">
                        <h4 class="font-semibold text-gray-700 bg-gray-100 px-3 py-2 rounded-md mb-2">
                            Kelas {{ namaKelas }} ({{ list.length }} siswa)
                        </h4>
                        <div class="space-y-2">
                            <div v-for="p in list" :key="p.id"
                                class="flex items-center justify-between gap-3 px-3 py-2 border rounded-md">
                                <span class="text-sm font-medium text-gray-800">{{ p.siswa.nama }}</span>
                                <div class="flex gap-1">
                                    <button v-for="st in STATUS" :key="st" type="button"
                                        @click="statusMap[p.id] = st"
                                        :class="[
                                            'px-3 py-1 text-xs rounded-md capitalize transition',
                                            statusMap[p.id] === st
                                                ? warnaStatus(st) + ' ring-2 ring-offset-1 ring-current font-semibold'
                                                : 'bg-gray-50 text-gray-500 hover:bg-gray-100'
                                        ]">
                                        {{ st }}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end">
                    <button type="submit" :disabled="form.processing"
                        class="px-6 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50">
                        {{ form.processing ? 'Menyimpan...' : 'Simpan Perubahan' }}
                    </button>
                </div>
            </form>
        </div>
    </AuthenticatedLayout>
</template>
