<script setup>
import { ref, reactive, computed, watch } from 'vue';
import { Head, useForm } from '@inertiajs/vue3';
import axios from 'axios';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';

const props = defineProps({
    daftarEkstra: Array,
    tahunAktif: Object,
    today: String,
});

const form = useForm({
    ekstra_id: '',
    tanggal: props.today,
    materi: '',
    deskripsi: '',
    foto: null,        // ← tambah ini
    presensi: [],
});

const previewUrl = computed(() =>
    form.foto ? URL.createObjectURL(form.foto) : null
);

watch(() => form.foto, (newVal, oldVal) => {
    if (oldVal) URL.revokeObjectURL(URL.createObjectURL(oldVal));
});


// Data siswa dikelompokkan per kelas: { "10 TKJ 1": [ {id, nama...} ], ... }
const grupSiswa = ref({});
const loadingSiswa = ref(false);
// Peta status: { siswa_id: 'hadir' }
const statusMap = reactive({});

const STATUS = ['hadir', 'izin', 'sakit', 'alpha'];

// Saat pilih ekstra → ambil siswa peserta
const loadSiswa = async () => {
    if (!form.ekstra_id) {
        grupSiswa.value = {};
        return;
    }
    loadingSiswa.value = true;
    try {
        const { data } = await axios.get(route('pelatih.kegiatan.siswa'), {
            params: { ekstra_id: form.ekstra_id },
        });
        grupSiswa.value = data;

        // Set default semua "hadir"
        Object.keys(statusMap).forEach((k) => delete statusMap[k]);
        Object.values(data).flat().forEach((s) => {
            statusMap[s.id] = 'hadir';
        });
    } catch (e) {
        alert('Gagal memuat data siswa.');
    } finally {
        loadingSiswa.value = false;
    }
};

const submit = () => {
    form.presensi = Object.entries(statusMap).map(([siswa_id, status]) => ({
        siswa_id: Number(siswa_id),
        status,
    }));
    form.post(route('pelatih.kegiatan.store'), {
        forceFormData: true, // ← pastikan dikirim sebagai multipart
    });
};


// Helper warna badge status
const warnaStatus = (status) => ({
    hadir: 'bg-green-100 text-green-700',
    izin:  'bg-yellow-100 text-yellow-700',
    sakit: 'bg-orange-100 text-orange-700',
    alpha: 'bg-red-100 text-red-700',
}[status]);
</script>

<template>
    <Head title="Buat Kegiatan" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold text-gray-800">Buat Kegiatan Ekstra</h2>
        </template>

        <div class="py-8 max-w-4xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <form @submit.prevent="submit" class="space-y-6">

                <!-- Detail Kegiatan -->
                <div class="bg-white shadow rounded-lg p-6 space-y-4">
                    <h3 class="text-lg font-medium">Detail Kegiatan</h3>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Ekstrakurikuler</label>
                            <select v-model="form.ekstra_id" @change="loadSiswa"
                                class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
                                <option value="">-- Pilih Ekstra --</option>
                                <option v-for="e in daftarEkstra" :key="e.id" :value="e.id">{{ e.nama }}</option>
                            </select>
                            <div v-if="form.errors.ekstra_id" class="text-sm text-red-600 mt-1">{{ form.errors.ekstra_id }}</div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Tanggal</label>
                            <input v-model="form.tanggal" type="date"
                                class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500" />
                            <div v-if="form.errors.tanggal" class="text-sm text-red-600 mt-1">{{ form.errors.tanggal }}</div>
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Materi</label>
                        <input v-model="form.materi" type="text" placeholder="Contoh: Latihan baris-berbaris"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500" />
                        <div v-if="form.errors.materi" class="text-sm text-red-600 mt-1">{{ form.errors.materi }}</div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Deskripsi (opsional)</label>
                        <textarea v-model="form.deskripsi" rows="3"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"></textarea>
                    </div>

                    <div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Foto Kegiatan (opsional)</label>
    <input type="file" accept="image/*" capture="environment"
        @change="form.foto = $event.target.files[0]"
        class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100" />
    <p class="text-xs text-gray-400 mt-1">
        Di HP akan membuka kamera. Di komputer bisa pilih file. Maks 5MB.
    </p>
    <div v-if="form.errors.foto" class="text-sm text-red-600 mt-1">{{ form.errors.foto }}</div>

    <!-- Preview -->
    <div v-if="form.foto" class="mt-2">
        <img :src="previewUrl" alt="Preview" class="h-32 rounded-md border object-cover" />
    </div>
</div>

                </div>

                <!-- Presensi Grouping per Kelas -->
                <div class="bg-white shadow rounded-lg p-6">
                    <h3 class="text-lg font-medium mb-4">Presensi Siswa</h3>

                    <div v-if="loadingSiswa" class="text-center text-gray-400 py-8">Memuat siswa...</div>

                    <div v-else-if="!form.ekstra_id" class="text-center text-gray-400 py-8">
                        Pilih ekstrakurikuler dulu untuk memuat daftar siswa.
                    </div>

                    <div v-else-if="Object.keys(grupSiswa).length === 0" class="text-center text-gray-400 py-8">
                        Belum ada siswa yang terdaftar di ekstra ini.
                    </div>

                    <div v-else class="space-y-6">
                        <!-- Loop per kelas -->
                        <div v-for="(siswaList, namaKelas) in grupSiswa" :key="namaKelas">
                            <h4 class="font-semibold text-gray-700 bg-gray-100 px-3 py-2 rounded-md mb-2">
                                Kelas {{ namaKelas }} ({{ siswaList.length }} siswa)
                            </h4>
                            <div class="space-y-2">
                                <div v-for="s in siswaList" :key="s.id"
                                    class="flex items-center justify-between gap-3 px-3 py-2 border rounded-md">
                                    <span class="text-sm font-medium text-gray-800">{{ s.nama }}</span>
                                    <div class="flex gap-1">
                                        <button v-for="st in STATUS" :key="st" type="button"
                                            @click="statusMap[s.id] = st"
                                            :class="[
                                                'px-3 py-1 text-xs rounded-md capitalize transition',
                                                statusMap[s.id] === st
                                                    ? warnaStatus(st) + ' ring-2 ring-offset-1 ring-current font-semibold'
                                                    : 'bg-gray-50 text-gray-500 hover:bg-gray-100'
                                            ]">
                                            {{ st }}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tombol Simpan -->
                <div class="flex justify-end gap-3">
                    <button type="submit" :disabled="form.processing || Object.keys(grupSiswa).length === 0"
                        class="px-6 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50">
                        {{ form.processing ? 'Menyimpan...' : 'Simpan Kegiatan' }}
                    </button>
                </div>
            </form>
        </div>
    </AuthenticatedLayout>
</template>
