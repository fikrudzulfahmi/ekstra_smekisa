<script setup>
import { Head, Link, router } from '@inertiajs/vue3';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';

defineProps({ kegiatan: Array });

const formatTanggal = (t) =>
    new Date(t).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });

const hapus = (item) => {
    if (confirm(`Hapus kegiatan "${item.materi}" tanggal ${formatTanggal(item.tanggal)}?`)) {
        router.delete(route('pelatih.kegiatan.destroy', item.id), { preserveScroll: true });
    }
};
</script>

<template>
    <Head title="History Kegiatan" />

    <AuthenticatedLayout>
        <template #header>
            <div class="flex items-center justify-between">
                <h2 class="text-xl font-semibold text-gray-800">History Kegiatan</h2>
                <Link :href="route('pelatih.kegiatan.create')"
                    class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 text-sm">
                    + Buat Kegiatan
                </Link>
            </div>
        </template>

        <div class="py-8 max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-4">
<div v-for="item in kegiatan" :key="item.id"
    class="bg-white shadow rounded-lg p-5 flex items-center justify-between gap-4">
    <div class="flex-1">
        <div class="flex items-center gap-2">
            <span class="text-xs bg-indigo-100 text-indigo-700 rounded px-2 py-0.5">{{ item.ekstra.nama }}</span>
            <span class="text-sm text-gray-400">{{ formatTanggal(item.tanggal) }}</span>
        </div>
        <h3 class="font-semibold text-gray-800 mt-1">{{ item.materi }}</h3>
        <p v-if="item.deskripsi" class="text-sm text-gray-500 mt-0.5">{{ item.deskripsi }}</p>

        <!-- Rekap ringkas -->
        <div class="flex gap-3 mt-2 text-xs">
            <span class="text-green-600">Hadir: {{ item.hadir_count }}</span>
            <span class="text-yellow-600">Izin: {{ item.izin_count }}</span>
            <span class="text-orange-600">Sakit: {{ item.sakit_count }}</span>
            <span class="text-red-600">Alpha: {{ item.alpha_count }}</span>
            <span class="text-gray-500">Total: {{ item.total_count }}</span>
        </div>
    </div>

    <!-- Thumbnail Foto (jika ada) -->
    <div v-if="item.foto" class="shrink-0">
        <img :src="`/storage/${item.foto}`" alt="Foto Kegiatan"
            class="h-20 w-20 rounded-lg border object-cover" />
    </div>

    <!-- Tombol Aksi -->
    <div class="flex gap-3 shrink-0">
        <Link :href="route('pelatih.kegiatan.edit', item.id)"
            class="text-blue-600 hover:underline text-sm">Edit</Link>
        <button @click="hapus(item)" class="text-red-600 hover:underline text-sm">Hapus</button>
    </div>
</div>


            <div v-if="kegiatan.length === 0" class="bg-white shadow rounded-lg p-8 text-center text-gray-400">
                Belum ada kegiatan. Klik "Buat Kegiatan" untuk memulai.
            </div>
        </div>
    </AuthenticatedLayout>
</template>
