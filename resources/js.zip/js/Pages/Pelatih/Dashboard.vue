<script setup>
import { Head } from '@inertiajs/vue3';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
</script>

<template>
    <Head title="Dashboard Pelatih" />
    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold text-gray-800">Dashboard Pelatih</h2>
        </template>
        <div class="py-8 max-w-6xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow rounded-lg p-6">
                <p class="text-gray-600">Selamat datang, Pelatih! 👋</p>
                <p class="text-sm text-gray-400 mt-2">Buat kegiatan baru atau lihat history dari menu di samping.</p>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
