<script setup>
import { computed } from 'vue';
import { Link, usePage } from '@inertiajs/vue3';

const page = usePage();
const role = computed(() => page.props.auth?.user?.role);

// Menu untuk admin
const menuAdmin = [
    { label: 'Dashboard', route: 'admin.dashboard' },
    { label: 'Tahun Pelajaran', route: 'admin.tahun-pelajaran.index' },
    { label: 'Kelas', route: 'admin.kelas.index' },
    { label: 'Ekstra', route: 'admin.ekstra.index' },
    { label: 'Pelatih', route: 'admin.pelatih.index' },
    { label: 'Siswa', route: 'admin.siswa.index' },
    { label: 'Laporan per Kegiatan', route: 'admin.laporan.index' },
    { label: 'Laporan per Kelas', route: 'admin.laporan.per-kelas' },
];

// Menu untuk pelatih
const menuPelatih = [
    { label: 'Dashboard', route: 'pelatih.dashboard' },
    { label: 'Buat Kegiatan', route: 'pelatih.kegiatan.create' },
    { label: 'History Kegiatan', route: 'pelatih.kegiatan.index' },
];

const menu = computed(() => (role.value === 'admin' ? menuAdmin : menuPelatih));

const isActive = (routeName) => {
    // aktif jika route saat ini diawali dengan nama menu (tanpa .index dsb)
    const base = routeName.replace(/\.(index|create)$/, '');
    return route().current(base) || route().current(routeName) || route().current(base + '.*');
};
</script>

<template>
    <aside class="w-60 bg-gray-800 text-gray-100 min-h-screen flex flex-col print:hidden">
        <div class="px-5 py-4 border-b border-gray-700">
            <h1 class="text-lg font-bold">Presensi Ekskul</h1>
            <p class="text-xs text-gray-400 capitalize">{{ role }}</p>
        </div>
        <nav class="flex-1 px-2 py-4 space-y-1">
            <Link v-for="m in menu" :key="m.route" :href="route(m.route)"
                :class="[
                    'block px-3 py-2 rounded-md text-sm transition',
                    isActive(m.route) ? 'bg-indigo-600 text-white' : 'text-gray-300 hover:bg-gray-700'
                ]">
                {{ m.label }}
            </Link>
        </nav>
    </aside>
</template>
