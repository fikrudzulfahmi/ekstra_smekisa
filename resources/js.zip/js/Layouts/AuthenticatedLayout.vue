<script setup>
import { ref } from 'vue';
import { Link, usePage } from '@inertiajs/vue3';
import Sidebar from '@/Components/Sidebar.vue';
import FlashMessage from '@/Components/FlashMessage.vue';

const page = usePage();
const user = page.props.auth?.user;
</script>

<template>
    <div class="min-h-screen bg-gray-100 flex">
        <!-- Sidebar -->
        <Sidebar />

        <!-- Konten Utama -->
        <div class="flex-1 flex flex-col">
            <!-- Topbar -->
            <header class="bg-white shadow-sm print:hidden">
                <div class="px-6 py-4 flex items-center justify-between">
                    <div>
                        <slot name="header" />
                    </div>
                    <div class="flex items-center gap-4">
                        <span class="text-sm text-gray-600">{{ user?.name }}</span>
                        <Link :href="route('profile.edit')" class="text-sm text-gray-500 hover:text-gray-800">
                            Profil
                        </Link>
                        <Link :href="route('logout')" method="post" as="button"
                            class="text-sm text-red-600 hover:underline">
                            Logout
                        </Link>
                    </div>
                </div>
            </header>

            <!-- Isi halaman -->
            <main class="flex-1">
                <slot />
            </main>
        </div>

        <!-- Notifikasi Flash -->
        <FlashMessage />
    </div>
</template>
